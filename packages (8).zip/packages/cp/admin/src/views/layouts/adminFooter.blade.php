<footer class="main-footer">
    <strong>Copyright &copy; 2022-2023 <a href="https://a2sys.co/">a2sys</a>.</strong> All rights reserved.
  </footer>