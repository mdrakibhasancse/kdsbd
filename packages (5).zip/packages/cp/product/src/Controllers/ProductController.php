<?php

namespace Cp\Product\Controllers;

use Event;
use Validator;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Cp\Product\Models\Cart;
use Cp\Product\Models\Order;
use Cp\Product\Models\OrderItem;
use Cp\Product\Models\Product;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;

class ProductController extends Controller
{
  
  
}