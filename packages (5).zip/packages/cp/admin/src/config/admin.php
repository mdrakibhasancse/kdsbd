<?php

return [

	//test
    'message' => 'I heard you the first time.',

    //total products of packages and 1 day base money (BDT)
    'package' => [
 
    ],
];