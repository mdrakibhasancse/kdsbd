 <!-- The Modal -->
  <div class="modal fade pt-5 mt-5" id="myModalLg">
    <div class="modal-dialog modal-lg w3-animate-zoom w3-round" style="width: 385px;" >
        <div id="modalLargeFeed">
            @include('frontend::welcome.includes.modals.location')
        </div>
    </div>
</div>
  