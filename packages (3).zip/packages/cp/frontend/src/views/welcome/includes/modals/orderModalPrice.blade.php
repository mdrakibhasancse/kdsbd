@push('css')

@endpush

<div id="orderModalPrice" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content border-0">
    <div class="modal-body text-center">
       <p class="w3-large font-weight-bold">Orders below 1000tk are not accepted</p>
        <a href="{{url('/')}}" class="btn btn-dark py-3 px-5">Go Shop</a>
    </div> 
    </div>
  </div> 
</div> 




