 <!-- The Modal -->
<div class="modal fade" id="myModalLg">
    <div class="modal-dialog modal-dialog-centered modal-lg modalLargeFeed">
        @include('frontend::welcome.includes.modals.location')
    </div>
</div>





  