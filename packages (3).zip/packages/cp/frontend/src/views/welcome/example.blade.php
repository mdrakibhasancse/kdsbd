    {{-- <div class="container py-4">
        <div class="row">
            <div class="col-6 col-lg-2 mb-1">
              <div class="info-box w3-white w3-border w3-border-indigo w3-hover-border-green w3-round-large py-1 px-1">
                <i class="icon-shipping text-primary"></i>
                <div class="info-box-content">
                    <h4 class="font1 line-height-1 ls-10">FREE SHIPPING </h4>
                </div>
                <!-- End .info-box-content -->
               </div>
            </div>
            <!-- End .info-box -->
            <div class="col-6 col-lg-2 mb-1">
                <div class="info-box w3-white w3-border w3-border-indigo w3-hover-border-green w3-round-large py-1 px-1">
                    <i class="icon-money text-primary"></i>
                    <div class="info-box-content">
                        <h4 class="font1 line-height-1 ls-10">MONEY BACK GUARANTEE</h4>
                    </div>
                    <!-- End .info-box-content -->
                </div>
            </div>

            <div class="col-6 col-lg-2 mb-1">
                <div class="info-box w3-white w3-border w3-border-indigo w3-hover-border-green w3-round-large py-1 px-1">
                    <i class="icon-support text-primary"></i>

                    <div class="info-box-content">
                        <h4 class="font1 line-height-1 ls-10">ONLINE SUPPORT</h4>
                    </div>
                    <!-- End .info-box-content -->
                </div>
            </div>
            <!-- End .info-box -->
            <div class="col-6 col-lg-2 mb-1">
                <div class="info-box w3-white w3-border w3-border-indigo w3-hover-border-green w3-round-large py-1 px-1">
                    <i class="icon-secure-payment text-primary"></i>

                    <div class="info-box-content">
                        <h4 class="font1 line-height-1 ls-10">SECURE PAYMENT</h4>
                    </div>
                    <!-- End .info-box-content -->
                </div>
            </div>
            <!-- End .info-box -->

            <div class="col-6 col-lg-2 mb-1">
                <div class="info-box w3-white w3-border w3-border-indigo w3-hover-border-green w3-round-large py-1 px-1">
                    <i class="icon-secure-payment text-primary"></i>

                    <div class="info-box-content">
                        <h4 class="font1 line-height-1 ls-10">SECURE PAYMENT</h4>
                    </div>
                    <!-- End .info-box-content -->
                </div>
            </div>
            <!-- End .info-box -->

            <div class="col-6 col-lg-2 mb-1">
                <div class="info-box w3-white w3-border w3-border-indigo w3-hover-border-green w3-round-large py-1 px-1">
                    <i class="icon-secure-payment text-primary"></i>

                    <div class="info-box-content">
                        <h4 class="font1 line-height-1 ls-10">SECURE PAYMENT</h4>
                    </div>
                    <!-- End .info-box-content -->
                </div>
            </div>
            <!-- End .info-box -->

            
        </div>
    </div> --}}