 <!-- The Modal -->
  <div class="modal fade" id="myModalLg">
    <div class="modal-dialog modal-lg w3-animate-zoom w3-round">
 
      <div id="modalLargeFeed">
        <div class="card card-widget">  
          <div class="card-body">
            <div  style="min-height: 200px;" class=""></div>
          </div>
          <div class="overlay modal-feed"><i class="fas fa-2x fa-sync-alt fa-spin w3-xxxlarge w3-text-blue"></i>
          </div>
        </div>
      </div>
    </div>
  </div>

  

  