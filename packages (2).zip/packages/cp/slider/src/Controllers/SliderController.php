<?php

namespace Cp\Slider\Controllers;


use App\Http\Controllers\Controller;


class SliderController extends Controller
{
}
