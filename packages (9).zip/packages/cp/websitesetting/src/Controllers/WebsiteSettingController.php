<?php

namespace Cp\WebsiteSetting\Controllers;


use App\Http\Controllers\Controller;


class WebsiteSettingController extends Controller
{
}
