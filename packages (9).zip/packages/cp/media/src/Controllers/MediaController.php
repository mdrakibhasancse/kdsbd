<?php

namespace Cp\Media\Controllers;


use App\Http\Controllers\Controller;


class MediaController extends Controller
{
}
