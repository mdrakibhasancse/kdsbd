<?php
 
// lang/en/messages.php
 
return [
    'welcome' => 'আমাদের এপ্লিকেশনে স্বাগতম',
];