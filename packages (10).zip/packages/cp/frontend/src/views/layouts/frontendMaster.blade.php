<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>kdsbd</title>

    <meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="kdsbd">
    <meta name="author" content="SW-THEMES">
    <meta name="csrf-token" content="{{ csrf_token() }}" />

   <!-- Favicon -->
    <link rel="shortcut icon" href="{{ route('imagecache', ['template' => 'original', 'filename' => $ws->favicon()]) }}" type="image/x-icon" />
    <link rel="apple-touch-icon" href="{{ route('imagecache', ['template' => 'original', 'filename' => $ws->favicon()]) }}">
    <link rel="icon" href="{{ route('imagecache', ['template' => 'original', 'filename' => $ws->favicon()]) }}" type="image/x-icon">


    <script>
        WebFontConfig = {
            google: {
                families: ['Open+Sans:300,400,600,700,800', 'Poppins:300,400,500,600,700', 'Oswald:300,400']
            }
        };
        (function(d) {
            var wf = d.createElement('script'),
                s = d.scripts[0];
            wf.src = 'assets/js/webfont.js';
            wf.async = true;
            s.parentNode.insertBefore(wf, s);
        })(document);
    </script>

    <link rel="stylesheet" href="{{asset("https://www.w3schools.com/w3css/4/w3.css")}}">

  

    <!-- Plugins CSS File -->
    <link rel="stylesheet" href="{{asset("/frontend/assets/css/bootstrap.min.css")}}">

    <!-- Main CSS File -->
    <link rel="stylesheet" href="{{asset("/frontend/assets/css/demo22.min.css")}}">
    <link rel="stylesheet" type="text/css" href="{{asset("/frontend/assets/vendor/simple-line-icons/css/simple-line-icons.min.css")}}">

    <link rel="stylesheet" type="text/css" href="{{asset("/frontend/assets/vendor/fontawesome-free/css/all.min.css")}}">

    <!-- Select2 -->
  <link rel="stylesheet" href="{{asset('/')}}alt/plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="{{asset('/')}}alt/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10">

     <style>
        .header-search-inline .form-control {
            max-width: 500px !important;
        }
        .header-search-category .form-control {
            border-radius: 1rem 0 0 1rem !important;
            
        }

        .header-search-category .btn {
            border-radius: 0 1rem 1rem 0 !important;
        }

        .newsletter-popup {
            max-width: 485px !important;
        }

        @media (max-width: 991px) {
            .header-search-wrapper {
                height: 45px !important;
                border: 0px !important;
            }
        }

        .header-user i {
            line-height: 52px;
            text-align: center;
        }

        .cart-dropdown .product-image-container {
           max-width: 70px !important;
        }

        

        
     </style>


     @stack('css')
</head>

<body class="loaded">
    <div class="page-wrapper">
        <div class="top-notice bg-white">
            <div class="container areaLocation">
                @include('frontend::welcome.includes.areaLocation')
            </div>
        </div>



		@include('frontend::layouts.frontendHeader') 

        <main class="main" style="background-color: #fafafa ">
           @yield('content')
        </main>
        
        <!-- End .main -->
        @include('frontend::layouts.frontendFooter')
       
    </div>
  


    @include('frontend::welcome.includes.mobileMenuContainer')


    <div class="sticky-navbar">
        <div class="sticky-info">
            <a href="{{ url('/')}}">
                <i class="icon-home"></i>Home
            </a>
        </div>
        <div class="sticky-info">
            <a href="{{route('categoriesAll')}}" class="">
                <i class="icon-bars"></i>Categories
            </a>
        </div>
        <div class="sticky-info">
            <a href="wishlist.html" class="">
                <i class="icon-wishlist-2"></i>Wishlist
            </a>
        </div>
        <div class="sticky-info">
            @if(Auth::check())
            <a href="{{route('user.dashboard')}}"><i class="icon-user-2"></i>  Account</a>
            @else
            {{-- <a href="{{ route('registerModal', ['register-modal-open']) }}" class="register-modal-lg"><i class="icon-user-2"></i> Account</a> --}}
            <a class="" data-target="#modal_register"  data-toggle="modal" style="cursor: pointer">
                Account
            </a>
            @endif
        </div>
        <div class="sticky-info">
            <a href="{{ route('checkout')}}" class="">
                <i class="icon-shopping-cart position-relative">
                    <span class="cart-count badge-circle totalCartItems">{{totalCartItems()}}</span>
                </i>Cart
            </a>
        </div>
    </div>



    @include('frontend::welcome.includes.modals.modalLg')
    @include('frontend::welcome.includes.modals.registerModal')


    

    

   
    <!-- End .newsletter-popup -->

    <a id="scroll-top" href="#top" title="Top" role="button"><i class="icon-angle-up"></i></a>

    <!-- Plugins JS File -->
    <script src="{{asset("/frontend/assets/js/jquery.min.js")}}"></script>
    <script src="{{asset("/frontend/assets/js/bootstrap.bundle.min.js")}}"></script>
    <script src="{{asset("/frontend/assets/js/plugins.min.js")}}"></script>
    <script src="{{asset("/frontend/assets/js/optional/isotope.pkgd.min.js")}}"></script>
    <script src="{{asset("/frontend/assets/js/jquery.appear.min.js")}}"></script>
    <script src="{{asset("/frontend/assets/js/jquery.plugin.min.js")}}"></script>
    <script src="{{asset("/frontend/assets/js/jquery.countdown.min.js")}}"></script>


    <!-- Main JS File -->
    <script src="{{asset("/frontend/assets/js/main.min.js")}}"></script>



    <script src="{{ asset('alte/plugins/select2/js/select2.full.min.js') }}"></script>
    <script src="{{asset('/')}}alt/plugins/select2/js/select2.full.min.js"></script>

     
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <script>
        function getIp(callback) {
            var ip = $(".ip").val();
            var infoUrl = 'https://ipinfo.io/json?ip=' + ip;
            fetch(infoUrl, {
                    headers: {
                        'Accept': 'application/json'
                    }
                })
                .then((resp) => resp.json())
                .catch(() => {
                    return {
                        country: '',
                    };
                })
                .then((resp) => callback(resp.country));
        }
        const phoneInputField = document.querySelector(".input-mobile");
        const phoneInput = window.intlTelInput(phoneInputField, {
         
            initialCountry: "bd",
            geoIpLookup: getIp,
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
            preferredCountries: ["bd", "us", "gb"],
            placeholderNumberType: "MOBILE",
            nationalMode: true,
        
            customContainer: "w-100",
            autoPlaceholder: "polite",
        });

     
   
    </script>

    <script type="text/javascript">
       
        $(document).ready(function () {
            $(document).on("submit", ".mobile-check-form", function(e) {
                e.preventDefault();
                var that = $(this);
                var url  = that.attr('data-url');
                var formData = that.serialize();
                if (phoneInput.isValidNumber()) {
                    $('#valid_mobile').val(phoneInput.getNumber());
                        document.getElementById('mobile-create-form').submit();
                } else {
                    // alert('Check Mobile Number Again');
                    $(".error_validation").html('Invalid Mobile Number');

                }
            }); 

        });
    </script>





    <script>
        $(function(){
            @if(!request()->cookie('area_name'))
            setTimeout(function(e){
            $('#myModalLg').modal('show');
            }, 500);

            $('.select2').select2({
                theme: 'bootstrap4'
            });
            @endif
        });
    </script>

    <script>
        $(function(){
            @if(request()->cookie('mobile_saved')) 
            $("#modal_register").modal('show');
            @endif
        });
    </script>

    <script>
        $(document).ready(function(){
            $(document).on('click', '.location-modal-lg', function(e) {
                e.preventDefault();
                var that = $(this),
                url = that.attr("href");
                $("#myModalLg").modal({
                    backdrop: false
                });

                $.ajax({
                    url: url,
                    type: "Get",
                    cache: false,
                    dataType: 'json',
                    beforeSend: function() {
                        $(".modal-feed").show();
                    },
                    complete: function() {
                        $(".modal-feed").hide();
                    },
                }).done(function(data) {

                    $('#modalLargeFeed').empty().append(data);

                    $('.select2').select2({
                        theme: 'bootstrap4'
                    });


                }).fail(function() {});
            });



            //delete cart Item
            $(document).on("click",".cartRemoveItem",function() {
                var that = $(this);
                var url  = that.attr('data-url');
                var result = confirm('Are you sure to delete this cart item?');
                if(result){
                    $.ajax({
                    url    : url,
                    method : "post",
                    success: function(result){
                        $(".headerCart").empty().append(result.view);
                        $(".checkoutItems").empty().append(result.checkoutItems);

                        that.closest('.product-details').find(".productCartItem").empty().append(result.productCartItem);

                        $(".totalCartAmount").html(result.totalCartAmount);
                        $(".totalDiscountCartAmount").html(result.totalDiscountCartAmount);
                        $(".totalOriginalCartAmount").html(result.totalOriginalCartAmount);
                        $(".totalCartItems").html(result.totalCartItems);
                        location.reload();

                        const Toast = Swal.mixin({
                            toast: true,
                            position: "top",
                            showConfirmButton: false,
                            timer: 3000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                                toast.onmouseenter = Swal.stopTimer;
                                toast.onmouseleave = Swal.resumeTimer;
                            }
                        });
                        Toast.fire({
                            icon: "success",
                            title: result.message
                        });
                        
                    },error:function(){
                        alert("Error");
                    }
                });
                }
            });


            $(document).on('click', '.register-modal-lg', function(e) {
                e.preventDefault();
                var that = $(this),
                url = that.attr("href");
                $("#modal_register").modal({
                    backdrop: false
                });

                $.ajax({
                    url: url,
                    type: "Get",
                    cache: false,
                    dataType: 'json',
                }).done(function(data) {

                    $('#modalLargeFeed').empty().append(data);


                }).fail(function() {});
            });


            $(document).on('submit', '.sendOtpMatch', function(e) {
                e.preventDefault();
                var that = $(this);
                var q = that.val();
                var url = that.attr('action');
                var type = that.attr('method');
                var data = new FormData(this);
                $.ajax({
                    url: url,
                    type: type,
                    cache : false,
                    dataType    : 'json',
                    processData : false,
                    contentType: false,
                    data: new FormData(this),
                    success: function(result){
                        if(result.success == true){
                            $(".sendOtpMatchData").empty().append(result.page);  
                        }else if(result.loginSuccess == true){
                            window.location.href = '/checkout';
                        }else{
                            const Toast = Swal.mixin({
                                toast: true,
                                position: "top",
                                showConfirmButton: false,
                                timer: 3000,
                                timerProgressBar: true,
                                didOpen: (toast) => {
                                    toast.onmouseenter = Swal.stopTimer;
                                    toast.onmouseleave = Swal.resumeTimer;
                                }
                            });
                            Toast.fire({
                                icon: "error",
                                title: result.message
                            });
                        }
                        
                    }
                });
            })

           
        });

    </script>


   
  

    {{-- <script type="text/javascript">
        $(document).ready(function () {
            var branches = <?php echo json_encode($branches); ?>;
            var areas = <?php echo json_encode($areas); ?>

            $(document).on("change", ".branch-select", function (e) {
                e.preventDefault();

                
                var that = $(this);
                var q = that.val();
                
                that.closest('form').find(".area-select").empty().append($('<option>', {
                    value: '',
                    text: 'select your area'
                }));


                $.each(areas, function (i, item) {
                    if (item.branch_id == q) {
                        that.closest('form').find(".area-select").append(
                            "<option value='" + item.id + "'>" + item.name_en +
                            "</option>");
                    }
                });
            });

        });
    </script> --}}



    @stack('js')
</body>

</html>